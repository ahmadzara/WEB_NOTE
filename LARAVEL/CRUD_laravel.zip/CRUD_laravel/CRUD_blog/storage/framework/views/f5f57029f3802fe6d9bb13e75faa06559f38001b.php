<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <title><?php echo e($title); ?></title>
    </head>
    <body>

        <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <nav class="nav m-3">
            <li class="nav-item">
                <a class="btn btn-success" href="<?php echo e(route('index')); ?>">Main Page</a>
            </li>
            <li class="nav-item mx-3">
                <a class="btn btn-primary" href="<?php echo e(route('categories.index')); ?>">Categories</a>
            </li>
            <li class="nav-item">
                <a class="btn btn-warning" href="<?php echo e(route('categories.create')); ?>">New Categories</a>
            </li>
        </nav>
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Title</td>
                    <td>Description</td>
                    <td>Active</td>
                    <td>Actions</td>
                    <td>Edit</td>
                    <td>Delete</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->title); ?></td>
                    <td><?php echo e($category->description); ?></td>
                    <td><?php echo e($category->active ? 'Yes' : 'No'); ?></td>
                    <td><a href="<?php echo e(route('categories.show',$category->id)); ?>" class="btn btn-primary">Show</a></td>
                    <td><a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-warning">Edit</a></td>
                    <td><a href="<?php echo e(route('categories.destroy',$category->id)); ?>" onclick="return confirm('Seriously Dude?')" class="btn btn-danger">Delete</a></td>
                    <td>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

    </body>
</html>
<?php /**PATH C:\Users\laptop\Desktop\echo\resources\views/categories.blade.php ENDPATH**/ ?>