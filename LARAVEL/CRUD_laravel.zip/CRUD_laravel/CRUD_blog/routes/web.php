<?php

use Illuminate\Support\Facades\Route;

Auth::routes();


// Route::get('/', function () {
//     return view('index');
// });
Route::get('/', 'App\Http\Controllers\HomeController@index')->name('index');

// CRUD
Route::get('/categories', 'App\Http\Controllers\CategoryController@index')->name('categories.index')->middleware('auth');
Route::get('/categories/create', 'App\Http\Controllers\CategoryController@create')->name('categories.create');
Route::get('/categories/{category}', 'App\Http\Controllers\CategoryController@show')->name('categories.show');
Route::post('/categories/store', 'App\Http\Controllers\CategoryController@store')->name('categories.store');
Route::get('/categories/edit/{category}', 'App\Http\Controllers\CategoryController@edit')->name('categories.edit');
Route::put('/categories/update/{category}', 'App\Http\Controllers\CategoryController@update')->name('categories.update');
Route::get('/categories/destroy/{category}', 'App\Http\Controllers\CategoryController@destroy')->name('categories.destroy');