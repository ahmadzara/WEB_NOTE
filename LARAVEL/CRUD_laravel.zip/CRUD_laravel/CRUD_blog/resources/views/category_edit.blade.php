<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <title>{{ $title }}</title>
    </head>
    <body>

        @include('layouts.message')
        <div class="container m-5">
               <div class="row">
                 <div class="col-md-12">
                      <div class="card">
                           <div class="card-header">
                             <h3>{{ $title }}</h3>
                           </div>
                           <div class="card-body">
                             <form action="{{ route('categories.update',$category->id) }}" method="POST">
                              @method('PUT')
                              @csrf
                                 <div class="form-group mb-3">
                                       <label for="title" class="form-label">Title:</label>
                                       <input type="text" name="title" id="title" value="{{ $category->title }}" class="form-control @error('title') is-invalid @enderror">
                                   @error('title')
                                   <div class="alert alert-danger">{{ $message }}</div>
                                   @enderror
                                 </div>
                                 <div class="form-group mb-3">
                                     <label for="description" class="form-label">Description:</label>
                                     <textarea class="form-control @error('description') is-invalid @enderror" name="description" id="description" rows="3">
                                        {{ $category->description }}
                                    </textarea>
                                     @error('description')
                                     <div class="alert alert-danger">{{ $message }}</div>
                                     @enderror
                                 </div>
                                 <div class="form-group mb-3">
                                     <label for="status" class="form-label">Status:</label><br>
                                     <select name="active" id="active">
                                         <option value="1" {{ <?php if($category->active==1) echo 'Selected' ?> }}>Active</option>
                                         <option value="0" {{ <?php if($category->active==0) echo 'Selected' ?> }}>Inactive</option>
                                     </select>
                                 </div>
                                  <button type="submit" class="btn btn-warning">Edit</button>
                                  <a href="{{ route('categories.index') }}" class="btn btn-primary">Cancel</a>
                             </form>
                           </div>
                      </div>
                 </div>
               </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

    </body>
</html>
