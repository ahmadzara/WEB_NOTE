<?php

namespace App\Http\Controllers;

use App\Models\Category;
// use Illuminate\Http\Request;
use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use Exception;

class CategoryController extends Controller
{
    public function index()
    {
        //$posts = DB::table('posts')->get(['id', 'title', 'description']);
        //$posts = DB::table('posts')->select(['id', 'title', 'description'])->get();
        // $posts = DB::table('posts')->orderBy('id','DESC')->get(['id', 'title', 'description']);
        // $posts = DB::table('posts')->where('id', 6)->get();
        // $posts = DB::table('posts')->where('id',"<>", 6)->get();
        // $posts = DB::table('posts')->orderBy('id','DESC')->paginate(1);
        // $postcounts = DB::table('posts')->count();

        $title = "Categories Management";
        $categories = Category::orderBy('id', 'desc')->get();
        return view('categories', compact('title','categories'));
    }

    public function show(Category $category)
    {
        $title = "Category Details";
        return view('category_show', compact('title','category'));
        // dd($category);
    }

    public function create()
    {
        $title = "Create Category";
        return view('category_create', compact('title'));
    }

    public function store(StoreCategoryRequest $request)
    {
    //   dd($request->all());
   $category = new Category([
          'title' => $request->get('title'),
          'description' => $request->get('description'),
          'active' => $request->get('active'),
     ]);

    //  we can use try catch block to handle exception
    try{
        // error handling, redirects to main page if successful, using the success session to display the message
        $category->save();
        // $categroy = new Category(); and then use $category->create($request->all());
        return redirect()->route('categories.index')->with('success', 'Category created successfully.');
    } catch(Exception $exception){
        return redirect()->route('categories.index')->with('error', 'Category creation failed.');
    }
    }


    public function update(UpdateCategoryRequest $request, Category $category)
    {
        // $category->title = $request->get('title');
        // $category->description = $request->get('description');
        // $category->active = $request->get('active');
        // $category->save();
        try{
            $category->update($request->all());
            return redirect()->route('categories.index')->with('success', 'Category updated successfully.');
        } catch(Exception $exception){
            return redirect()->route('categories.index')->with('error', 'Category update failed.');
        }
    }


    public function edit(Category $category)
    {
            $title = "Edit Category";
            return view('category_edit', compact('title','category'));
    }


    public function destroy(Category $category)
    {
        try{
            $category->delete();
            return redirect()->route('categories.index')->with('success', 'Category deleted successfully.');
        } catch(Exception $exception){
            return redirect()->route('categories.index')->with('error', 'Category deletion failed.');
        }
    }
}
