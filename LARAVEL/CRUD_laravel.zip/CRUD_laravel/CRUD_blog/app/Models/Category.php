<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

      // // you tell the model to work with invoices table
    // protected $table = 'invoices';
    // // if you want to use the primary key other than id
    // protected $primaryKey = 'order_id';

    // to let the model know that we do not need the timestasmp columns
    // protected $timestamps = 'false';

    protected $fillable = [
        'title',
        'description',
        'active',
    ];
}
